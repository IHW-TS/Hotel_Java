/*package MVC.controller.V1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import MVC.vue.V1.GchambreTable;

public class Caccueil implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(((JButton)e.getSource()).getText().equals("Gestion des r�servations")){
			new GchambreTable();
		}
	}
}
*/