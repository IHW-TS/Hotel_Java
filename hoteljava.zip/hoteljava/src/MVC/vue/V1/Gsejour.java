/*package MVC.vue.V1;

import java.awt.*;

import javax.swing.*;

import MVC.controller.V1.Csejour;



public class Gsejour extends GchambreTable{
	
	public Gsejour() {
	JButton valider = new JButton("valider le séjour");
    boutons.add(valider);
	Csejour s = new Csejour();
	valider.addActionListener(s);
    this.getContentPane().add(boutons, BorderLayout.SOUTH);
    this.pack();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Gsejour().setVisible(true);
	}

}*/
