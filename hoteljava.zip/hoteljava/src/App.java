import MVC.vue.AdminPage;
import MVC.vue.AdminRes;

import MVC.vue.ClientRes;
import MVC.vue.HotelRes;
import MVC.vue.PageAccueil;



public class App {
	public static void main(String[] args) throws Exception {
		
		//new AdminPage();
		//new HotelRes();
	    //new AdminPage();
		new PageAccueil();

		
	}
}

